package org.giscience.measures.repository;

import org.giscience.measures.rest.measure.MeasureOSHDB;
import org.giscience.measures.rest.server.RequestParameter;
import org.giscience.measures.tools.Index;
import org.giscience.measures.tools.Lineage;
import org.giscience.utils.geogrid.cells.GridCell;
import org.heigit.bigspatialdata.oshdb.api.db.OSHDBDatabase;
import org.heigit.bigspatialdata.oshdb.api.db.OSHDBJdbc;
import org.heigit.bigspatialdata.oshdb.api.mapreducer.MapAggregator;
import org.heigit.bigspatialdata.oshdb.api.object.OSMEntitySnapshot;
import org.heigit.bigspatialdata.oshdb.util.geometry.Geo;

import javax.ws.rs.Path;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.SortedMap;

import Test;
import Another.import;

@Path("api/" + MeasureNewMeasure3.name)
public class MeasureNewMeasure3 extends MeasureOSHDB<Number, OSMEntitySnapshot> {
    public static final String name = "new-measure-3";

    public MeasureNewMeasure3(OSHDBJdbc oshdb) {
        super(oshdb);
    }

    public MeasureNewMeasure3(OSHDBDatabase oshdb, OSHDBJdbc oshdb_keydb) {
        super(oshdb, oshdb_keydb);
    }

    @Override
    public Integer intervalInDays() {
        return 30;
    }

    @Override
    public Boolean refersToTimeSpan() {
        return true;
    }



    @Override
    public Integer defaultDaysBefore() {
        return 1440;
    }

    @Override
    public SortedMap<GridCell, Number> compute(MapAggregator<GridCell, OSMEntitySnapshot> mapReducer) throws Exception {
      MapAggregator<OSHDBCombinedIndex<GridCell, OSHDBTimestamp>, OSMEntitySnapshot> ___mapReducer2 = ___mapReducer.aggregateByTimestamp(snapshot -> snapshot.getTimestamp());

return Cast.result(
  Index.reduce(
    Index.map(
      ___mapReducer2
        .osmTag("highway", ___p.get("typeOfStreet").toString())
        .osmTag("maxspeed")
        .map(snapshot -> ___p.get("test").toInteger() * Geo.lengthOf(snapshot.getGeometry()))
        .sum(),
      (Integer x) -> {
        return x * 1.4;
      }
    ),
    Lineage::max
  )
);

    }
}
