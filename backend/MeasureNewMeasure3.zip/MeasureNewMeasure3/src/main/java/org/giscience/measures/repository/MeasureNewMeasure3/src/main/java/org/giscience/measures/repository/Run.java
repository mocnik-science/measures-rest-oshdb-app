package org.giscience.measures.repository;

import org.giscience.measures.rest.server.RestServer;
import org.heigit.bigspatialdata.oshdb.api.db.OSHDBH2;

import javax.ws.rs.core.UriBuilder;

public class Run {
    public static void main(String[] args) throws Exception {
        OSHDBH2 oshdb = new OSHDBH2("/data/dbs/sweden_20180112_z12_keytable.oshdb").multithreading(true);
        RestServer restServer = new RestServer(UriBuilder.fromPath("/").scheme("http").host("0.0.0.0").port(8080).build());
          restServer.register(new MeasureNewMeasure3(oshdb));
        restServer.run();
    }
}

